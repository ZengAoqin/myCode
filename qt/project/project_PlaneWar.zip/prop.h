#ifndef PROP_H
#define PROP_H


class Prop
{
public:
    Prop();
};

#endif // PROP_H