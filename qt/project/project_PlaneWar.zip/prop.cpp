#include "prop.h"

Prop::Prop()
{

}
